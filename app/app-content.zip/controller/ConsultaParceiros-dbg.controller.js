sap.ui.define([
        "./BaseController",
        "sap/ui/model/json/JSONModel",
        "sap/m/MessageBox",
        "sap/ui/model/Filter",
        "sap/ui/model/FilterOperator"
	],
	/**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
	function (BaseController, JSONModel, MessageBox, Filter, FilterOperator) {
		"use strict";

		return BaseController.extend("treinamento.l4e.app.controller.ConsultaParceiros", {
			onInit: function () {
                this.getRouter().getRoute("ConsultaParceiros").attachPatternMatched(this.handleRouteMatched, this);

            },
            
            handleRouteMatched: async function(){
                var that = this;

                $.ajax({
                    "url": "/api/parceiros",
                    "method": "GET",
                    success(data){
                        that.getView().setModel(new JSONModel(data), "Parceiros")
                    },
                    error(){

                    }

                })
            },

            onExcluir: async function(oEvent){
                var id = oEvent.getParameter('listItem').getBindingContext("Parceiros").getObject().id;
                this.getView().setBusy(true);

                await
                $.ajax({
                    "url": `/api/parceiros/${id}`,
                    "method": "DELETE",
                    success(data){
                        MessageBox.success("Excluído com sucesso!")
                    },
                    error(){
                        MessageBox.error("Não foi possível excluir o Parceiro.")
                    }

                });
                await this.handleRouteMatched();
                this.getView().setBusy(false);

            },

            onNavEditarParceiro: function(oEvent){
                var parceiroId = oEvent.getSource().getBindingContext("Parceiros").getObject().id; 
                this.getRouter().navTo("EditarParceiros", {id: parceiroId});
            },

             // Função do campo de busca (SearchField)
            onSearch: function(oEvent){
                var aFilters = [];
                var sQuery = oEvent.getSource().getValue();
                if (sQuery && sQuery.length > 0) {
                    var filter = new Filter("nome", FilterOperator.Contains, sQuery);
                    aFilters.push(filter);
                }

                var oList = this.byId("tableParceiros");
                var oBinding = oList.getBinding("items");
                oBinding.filter(aFilters, "Application");
            }
		});
	});

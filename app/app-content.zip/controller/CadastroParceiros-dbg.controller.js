sap.ui.define([
        "./BaseController",
        "sap/ui/model/json/JSONModel",
        "sap/m/MessageBox"
	],
	/**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
	function (BaseController, JSONModel, MessageBox) {
		"use strict";

		return BaseController.extend("treinamento.l4e.app.controller.CadastroParceiros", {
			onInit: function () {
                // Rota de cadastro
                this.getRouter().getRoute("CadastroParceiros").attachPatternMatched(this.handleRouteMatched, this);
                // Rota de edição
                this.getRouter().getRoute("EditarParceiros").attachPatternMatched(this.handleRouteMatchedEditarParceiro, this);
            },
            
            handleRouteMatched: function(){
                this.getView().setModel(new JSONModel({
                    "status": "A" 
                }), "Parceiro");
            },

            handleRouteMatchedEditarParceiro: async function(){
                var that = this;
                var id = this.getRouter().getHashChanger().getHash().split("/")[1];
                this.getView().setBusy(true);
                // Faz a chamada na API para pegar o parceiro selecionado na tabela.
                // Precisamos passar o ID na url para a API retornar apenas os dados do item selecionado.
                await 
                $.ajax({
                    "url": `/api/parceiros/${id}`, // concatena a URL com o ID
                    "method": "GET",
                    success(data) {
                        that.getView().setModel(new JSONModel(data), "Parceiro"); // salva o retorno da API (data) em um Model chamado 'Parceiro'
                    },
                    error() {
                        MessageBox.error("Não foi possível buscar os Parceiros.") //Se der erro de API, exibe uma mensagem ao usuário
                    }
                });
                this.getView().setBusy(false);
            },

            onChangeSwitch: function(oEvent){
                this.getView().getModel("Parceiro").setProperty("/status", oEvent.getSource().getState() === true ? "A" : "I" );
            },

            onConfirmar: async function(){
                var oParceiro = this.getView().getModel("Parceiro").getData();
                var that = this;
                console.log(oParceiro)

                if(this.getRouter().getHashChanger().getHash().search("EditarParceiros") === 0){

                    await $.ajax(`/api/parceiros/${oParceiro.id}`, { // Concatena o ID do parceiro selecionado na url
                    method: "PUT",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    // Cria a estrutura dos dados para enviar para API
                    data: JSON.stringify({
                        "nome": oParceiro.nome,
                        "tipo": oParceiro.tipo,
                        "status": oParceiro.status
                    }),
                    success() {
                        // Se a api retornar sucesso, exibe uma mensagem para o usuário e navega para a tela de "ConsultaParceiros"
                        MessageBox.success("Editado com sucesso!", {
                            onClose: function() {
                                that.getRouter().navTo("ConsultaParceiros");
                            }
                        });
                    },
                    error() {
                        //Se a api retornar erro, exibe uma mensagem ao usuário
                        MessageBox.error("Não foi possível editar o parceiro.");
                    }
                });

                }else{

                    this.getView().setBusy(true);

                    await $.ajax("/api/parceiros", {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        data: JSON.stringify(oParceiro),
                        success(){
                            MessageBox.success("Salvo com sucesso!");
                        },
                        error(){
                            MessageBox.error("Não foi possível salvar o parceiro.");
                        }
                    })

                    this.getView().setBusy(false);

                }
            },

            // Função do botão Cancelar
            onCancelar: function(){
                // Se a rota for a de "EditarParceiros", navega para a tela de Consuta
                // Senão, limpa o model 'Parceiro'
                if(this.getRouter().getHashChanger().getHash().search("EditarParceiros") === 0){
                    this.getRouter().navTo("ConsultaParceiros");
                }else{
                    this.getView().setModel(new JSONModel({"status": "A"}), "Parceiro")
                }
            }
		});
	});
